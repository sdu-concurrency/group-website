Change into the (sub)directory artifact/bin.
The directory contains a script "pe" that invokes our tool.
The script needs the JAVA_HOME environment variable to point to Java's installation directory. Run the following command:

export JAVA_HOME=/usr/lib/jvm/java-8-openjdk-amd64

The script should now be able to run.
To get a list of available commands, run "./pe help".

You should see this output:

List of available commands (<name of command>   <description>)
        help            Print this help
        theory          Run the tests from the original theoretical paper [Cruz-Filipe, Larsen, Montesi @ FoSSaCS 2017]
        lty15           Run the tests from the paper [Lange, Tuosto, Yoshida @ POPL 2015]
        lty15-seq               Run the tests from the paper [Lange, Tuosto, Yoshida @ POPL 2015] *with parallelisation disabled*
        benchmark               Run the extraction benchmarking suite (Warning: this takes a *long* time, possibly days or weeks depending on your hardware)
        bisimcheck              Check that the choreographies extracted in the benchmark are correct, i.e., they are bisimilar to the respective originals (Warning: this takes a *long* time, possibly days or weeks depending on your hardware)

You can now:
	1. run "./pe theory" to check that our tool works against the examples of its original theory
	2. run "./pe lty15" to check that our tool covers the manual examples mentioned in the paper submission, adapted from Lange et al. [2015]
	3. run "./pe lty15-seq", which is the same as (2) but without using our parallelisation feature. Comparing (2) to (3) gives the results for our Table 1.
	4. run "./pe benchmark" to run extraction on all our 1050 input choreographies for benchmarking.
	5. run "./pe bisimcheck" to run a check based on bisimilarity that checks for the correctness of the choreographies extracted in (4). (Run 4 first.)

1, 2, and 3 should execute relatively quickly and we expect all reviewers to be able to run them.
4 and 5 are very long and extensive tests, which require high amounts of RAM and CPU time.
Running 4 and 5 completely might require weeks, depending on your harware, so we tried our best to give you meaningful partial results:
	- you can interrupt the "benchmark" task at any time (by CTRL-C). All results accumulated so far are saved in files inside of subdirectory "tests". You can run this task incrementally, i.e., it will not re-compute results computed in previous runs.
	- if the "bisimcheck" task does not find some choreographies (because you stopped extraction), it simply skips them and does not count them in the final total.

Running "benchmark" produces two files in directory "tests".
Those with prefix "extraction" contain the extraction of each corresponding network found in the respective "projection" file.
Those with prefix "stats" give (a superset of) the statistics that we used in the paper submission (e.g., running time).

When you run "bisimcheck", expect many timeouts (actually for most choreographies).
Bisimilarity is very expensive and our tests are big. The important bit is that all results are either OKs or timeouts.
